let num = Math.ceil(Math.random(1,100) * 100);
console.log(num);
   