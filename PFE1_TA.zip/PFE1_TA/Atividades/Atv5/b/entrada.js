var num = prompt("Digite um número: ");
var num1 = prompt("Digite um outro número: ");
var soma = Number(num) + Number(num1);
console.log(`A soma dos numero é ${soma}`);
