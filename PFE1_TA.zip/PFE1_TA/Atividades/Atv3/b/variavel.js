let idade = 5;

if (idade > 2){
    let nome = "Rafael";
}
console.log(nome);

//Só ser posível usar a variavel dentro do bloco
