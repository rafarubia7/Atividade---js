let nota = prompt("Digite sua nota: ");
if (nota > 7){
    alert("Aprovado!")
}if(nota >= 5){
    alert("Recuperação!")
}else {
    alert("Reprovado!")
}