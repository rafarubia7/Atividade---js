function alterarCorDeFundo(){
    document.body.style.backgroundColor = "grey";
}

const botao = document.getElementById("meuBotao");
botao.addEventListener("click", alterarCorDeFundo);