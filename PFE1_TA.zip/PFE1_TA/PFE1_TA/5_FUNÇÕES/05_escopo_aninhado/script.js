let a = 10;
function multiplicar(x, y){
    let a = x * y;
    if(a > 10){
        let a =0;
        a++;
        console.log("if: " + a);
    }
    console.log("Função: " + a);
}
console.log("Fora: " + a);
multiplicar(3, 5);