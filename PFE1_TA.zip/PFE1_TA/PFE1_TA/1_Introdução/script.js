alert('Oi');
console.log('Opa, sou eu mesmo');
