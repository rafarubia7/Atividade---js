//1. Criar uma hierarquia baseasa na sua familia!
function destacarElemento() {
    const pai = document.getElementById("pai");
    pai.style.color = "red";  
    pai.style.fontWeight = "bold"; 
}