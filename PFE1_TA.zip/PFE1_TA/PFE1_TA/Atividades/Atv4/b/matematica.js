let num = prompt("Digite um numero: ");
console.log(Math.sqrt(num));
