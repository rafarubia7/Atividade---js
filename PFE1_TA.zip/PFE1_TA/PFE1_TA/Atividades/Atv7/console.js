console.log("Olaaa");
console.warn("Olaaa");
console.error("Olaaa");
