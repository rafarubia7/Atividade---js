var nome = "Rafael";
let idade = 17;
const cpf = "496.151.298.28";

nome = "Rafael";
idade = 23;
//não é possível alterar o valor de uma const

console.log(nome);
console.log(idade);
console.log(cpf);
