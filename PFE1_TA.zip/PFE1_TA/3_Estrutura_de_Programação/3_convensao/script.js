let nome3 = 'teste';
let $nome = 'teste2';
let _nome = 'teste3';

console.log(nome3);
console.log($nome);
console.log(_nome);
