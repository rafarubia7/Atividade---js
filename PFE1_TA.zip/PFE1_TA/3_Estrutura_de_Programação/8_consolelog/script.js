let idade = 17;
let nome = 'Rafael';
console.log(`O meu nome é ${nome} e tenho ${idade} anos`);

