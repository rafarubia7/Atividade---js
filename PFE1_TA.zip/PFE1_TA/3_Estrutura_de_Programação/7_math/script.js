let maior = Math.max(6, 20, 50, 350);
console.log(maior);

let menor = Math.min(5, 60, 460, 35);
console.log(menor);

let arredondar = Math.round(3.4);
console.log(arredondar);

let arredondarUp = Math.ceil(5.3);
console.log(arredondarUp);

let arredondarDown = Math.floor(4.6);
console.log(arredondarDown);

