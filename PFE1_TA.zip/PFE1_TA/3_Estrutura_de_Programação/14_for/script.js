for (let vassoura = 0; vassoura < 100; vassoura++){
    console.log(`A soma da posições da vassoura é: ${vassoura}`);
}