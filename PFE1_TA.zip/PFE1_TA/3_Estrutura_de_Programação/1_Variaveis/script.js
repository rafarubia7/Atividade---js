let nome = "Joana";

console.log(nome);
console.log(`O meu nome é: ${nome}`)

let laranja = 5;
console.log(laranja * laranja);

nome = "João";
console.log(nome);

laranja = 974
console.log(laranja);

let um = 1, dois = 2, tres = 3;
let t1 = 'Ola ', t2 = 'Pessoal';
console.log(um, dois, tres);
console.log(t1 + t1);

