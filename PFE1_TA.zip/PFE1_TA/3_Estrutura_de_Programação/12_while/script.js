let x = 0;
while(x < 10){
    console.log(x);
    x++;
}