let x = 100;
do{ //faça
    console.log(x / 2);    
    x = x - 5
}while (x >= 0); //enqunato