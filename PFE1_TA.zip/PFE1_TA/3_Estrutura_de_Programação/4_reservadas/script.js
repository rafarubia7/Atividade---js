// let if = 'teste';
// let function = 'teste2';
let functionTest = 'teste3';
let function1 = 'teste4';