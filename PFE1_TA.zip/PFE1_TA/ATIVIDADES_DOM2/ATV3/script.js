let contador = 1;

function adicionarElemento() {
    const item = document.createElement('li');
    item.textContent = 'item ' + contador;
    document.getElementById('lista').appendChild(item);
    contador++;
}

function removerElemento() {
    const lista = document.getElementById('lista');
    if (lista.children.length > 0) {
        lista.removeChild(lista.lastElementChild);
        contador--; 
    }
}
