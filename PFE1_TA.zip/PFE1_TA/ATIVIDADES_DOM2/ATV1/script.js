function exibirMensagem() {
    
    document.getElementById('texto').innerText = 'Texto novo';
}