let contador = 1; 

function adicionarElemento() {
    const item = document.createElement('li');
    item.textContent = 'item ' + contador;
    document.getElementById('lista').appendChild(item);
    contador++;
}