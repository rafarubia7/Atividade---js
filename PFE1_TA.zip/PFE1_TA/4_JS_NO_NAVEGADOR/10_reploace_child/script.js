let novoElemento = document.createElement('p');
let texto = document.createTextNode('A livia caiu de bike');
novoElemento.appendChild(texto);

let heading = document.querySelector('#titulo-principal');
let paiHeading = heading.parentNote;

paiHeading.replaceChild()