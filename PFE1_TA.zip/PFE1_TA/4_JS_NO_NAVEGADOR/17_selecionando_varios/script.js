let itensAzuis = document.querySelectorAll('.itens-azuis');
console.log(itensAzuis[0].style.color); 

itensAzuis[0].style.color = 'blue'; 
console.log(itensAzuis[0].style.color); 

let itensVerdes = document.querySelectorAll('.itens-verdes');
console.log(itensVerdes[0].style.color); 

itensVerdes[0].style.color = 'green'; 
console.log(itensVerdes[0].style.color); 