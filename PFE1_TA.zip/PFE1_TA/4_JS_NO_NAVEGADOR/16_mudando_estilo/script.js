let elemento = document.querySelector('#titulo-principal');

elemento.
setTimeout(function(){
     elemento.style.color = 'blue';
     elemento.style.backgroundColor = 'yellow';
     elemento.style.width = '400px';

}, 1000)