function imprimirConsole(){
    console.log("Olá galera!!!");
}

imprimirConsole();

function imprimirNumero(num){
    console.log("Número: " + num);
}

imprimirNumero(3);
imprimirNumero(-5);
imprimirNumero(25);

function numeroAleatorio() {
    num = Math.round(Math.random() * 10)
    console.log("Número: " + num);
}

numeroAleatorio();