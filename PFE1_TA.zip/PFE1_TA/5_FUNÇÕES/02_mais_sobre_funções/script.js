function multiplicarNumeros(){
    num1 = prompt("Digite um número: ");
    num2 = prompt("Digite um número: ");
    num3 = prompt("Digite um número: ");

    multi = (num1 * num2 * num3);
    alert("A multiplicação dos números é igual a: " + multi);
}

multiplicarNumeros()

// Condições para dirigir!
function condicaoDirigir(){
    idade = prompt("Digite sua idade: ");

if (idade >= 18) {
    cnh = prompt("Você tem habilitação?(S - sim, N - não):").toLowerCase();
    if (cnh == "s") {
        alert("Você pode dirigir!");
    }else {
        alert("Você não pode dirigir sem habilitação!");
    }
}
else{
    alert("Você não pode dirigir!");
}
}
condicaoDirigir();