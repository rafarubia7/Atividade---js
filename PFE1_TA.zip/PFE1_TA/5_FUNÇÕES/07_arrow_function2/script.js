// O número digitado deve ser multiplicado por 2
let multiplicadoPorDois = (a, b) => {
    a = prompt("Digite um número")
    return a * 2;
};
alert(multiplicadoPorDois());