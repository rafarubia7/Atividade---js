function potencia(base, exp=2){
    return Math.pow(base, exp)
}
console.log(potencia(5));
console.log(potencia(5, 3));