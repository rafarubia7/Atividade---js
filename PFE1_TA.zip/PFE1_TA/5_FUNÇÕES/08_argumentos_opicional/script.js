function saudação(nome , idade){
    if(idade === undefined){
        console.log("Olá " + nome);
    }else{
        console.log("Olá " + nome + " você tem " + idade + " anos");
    }
}
saudação("Kaio");
saudação("Kaio", 17);