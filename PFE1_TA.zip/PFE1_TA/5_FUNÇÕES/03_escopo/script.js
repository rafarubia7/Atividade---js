let y = 10; //dentro do bloco
function imprimir(){
    let y = 150;
    console.log(y);
}
imprimir();
console.log(y);