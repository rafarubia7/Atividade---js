console.log(5 > 2 ? 'sim' : 'não');
console.log(false ? '5' : '4');
console.log('Zé' == 'Zé' ? 'Olá Zé' : 'Não é o Zé');
