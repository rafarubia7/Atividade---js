console.log(typeof 'Alessandro sou eu mesmo');
console.log(typeof 'A');
console.log(typeof 'Teste');
console.log(typeof 'Infinity');
console.log(typeof Infinity);

