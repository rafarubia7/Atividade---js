function parOuImpar() {
    let valor = document.getElementById("valor").value; 

    if (valor % 2 == 0){
    document.getElementById("resultado").innerHTML =
        `<h1>Resposta: ${valor} é Par<br></h1>`;
    }else{
        document.getElementById("resultado").innerHTML =
        `<h1>Resposta: ${valor} é Ímpar<br></h1>`;
    }
}
