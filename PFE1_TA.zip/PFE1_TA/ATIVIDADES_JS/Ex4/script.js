function mostrarNotas() {
    let valor = document.getElementById("valor").value; 

    let notas100 = Math.floor(valor / 100);
    let resto100 = (valor % 100);

    let notas50 = Math.floor(resto100 / 50);
    let resto50 = (resto100 % 50);

    let notas10 = (resto50 / 10);

    if (valor % 10 != 0){
        alert("Não é possível sacar o valor!")
    }else{
    document.getElementById("resultado").innerHTML =
        `<h1>Notas de R$: 100 | ${notas100} notas<br></h1>
        <h1>Notas de R$: 50 | ${notas50} notas<br></h1>
        <h1>Notas de R$: 10 | ${notas10} notas<br></h1>`;
    }
}
