let contatos = [];


function adicionarContato() {
    let nome = prompt("Digite o nome do contato: ")
    let email = prompt("Digite o email do contato: ")

    //criar a lista de contatos
    let contato = {
        nome: nome,
        email: email,
    };

    //Adicionar o contato a lista de contatos
    contatos.push(contato);

    //Atualizar a lista de contatos
    atualizarListaContatos();
};

function atualizarListaContatos(){
    let listaContatos = document.getElementById("listaContatos");
    listaContatos.innerHTML = "";
    contatos.forEach(function(contato){
        let itemLista = document.createElement("li");
        itemLista.textContent = `Nome: ${contato.nome}, Email: ${contato.email}`;
        listaContatos.appendChild(itemLista);
        });
};

function removerContato(){
    let contatoRemovido = contatos.pop();

    if (contatoRemovido){
        alert(`Contato removido: ${contatoRemovido.nome}`)
    }else {
        alert("Nenhum contato para remover!");
    }
    atualizarListaContatos();
}