function mostrarPromocao() {
    let medicamento = document.getElementById("medicamento").value; 
    let preco = document.getElementById("preco").value; 

    preco = Math.floor(preco)
    let desconto = preco * 2;

    document.getElementById("resultado").innerHTML =
        `<h1>Promoção de ${medicamento}<br></h1>
        <h1>Leve 2 por apenas R$: ${desconto.toFixed(2)}<br></h1>`;
}
