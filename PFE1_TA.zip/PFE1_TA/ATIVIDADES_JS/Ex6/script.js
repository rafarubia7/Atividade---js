// Função para gerar a citação bibliográfica no estilo APA
function bibliografica() {
    // Obter o nome do autor a partir do input
    let nomeAutor = document.getElementById("nome").value;

    // Separar o nome em partes
    let partesNome = nomeAutor.trim().split(" ");

    // O sobrenome será a última parte do nome
    let sobrenome = partesNome[partesNome.length - 1];

    // As iniciais são as primeiras letras de cada parte do nome, exceto o sobrenome
    let iniciais = partesNome.slice(0, partesNome.length - 1).map(nome => nome.charAt(0) + '.').join(' ');

    // Gerar a referência no estilo APA: Sobrenome, iniciais
    let referenciaAPA = `${sobrenome}, ${iniciais}`;

    // Exibir a citação no resultado
    document.getElementById("resultado").textContent = `Citação Bibliográfica: ${referenciaAPA}`;
}
