function consultarCep() {
    const cep = document.getElementById("cep").value;
    const url = `https://viacep.com.br/ws/${cep}/json/`;
    fetch(url)
    .then(response => response.json())
    .then(data => exibirResultados(data))
    .catch(error => console.error("Ocorreu um erro na requisição"),error)
}
function exibirResultados(data){
    const resultadoDiv = document.getElementById("resultado");
    if(data.erro){
        resultadoDiv.innerHTML = "CEP não encontrado!"
    }else{
        const endereco =
        `<p> <strong>CEP:</strong> ${data.cep}</p>
        <p> <strong>Logradouro:</strong> ${data.logradouro}</p>
        <p> <strong>Bairro:</strong> ${data.localidade}</p>
        <p> <strong>Estado:</strong> ${data.uf}</p>`
        resultadoDiv.innerHTML = endereco;
    }
}