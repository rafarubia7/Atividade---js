//Atividade A
for (let i = 2; i <= 20; i += 2) {
    console.log(i);
}

//Atividade B
let numero = prompt('Digite um número para ver sua tabuada: ');

numero = Number(numero); 

for (let i = 1; i <= 10; i++) {
    console.log(`${numero} x ${i} = ${numero * i}`);
}

