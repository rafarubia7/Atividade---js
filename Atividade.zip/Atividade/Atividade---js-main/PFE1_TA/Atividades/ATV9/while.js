//Atividade A

let numero = 1; 
while (numero <= 10) { 
    console.log(numero); 
    numero++; 
}

//Atividade B
let senha;

while (senha !== "1234") {
    senha = prompt("Digite a senha:");
}

alert("Senha correta!"); 
