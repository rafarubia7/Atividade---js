//Atividade A
let numero = parseInt(prompt("Digite um número de 1 a 7:"));  

switch (numero) {
    case 1:
        console.log("Domingo");
        break;
    case 2:
        console.log("Segunda-feira");
        break;
    case 3:
        console.log("Terça-feira");
        break;
    case 4:
        console.log("Quarta-feira");
        break;
    case 5:
        console.log("Quinta-feira");
        break;
    case 6:
        console.log("Sexta-feira");
        break;
    case 7:
        console.log("Sábado");
        break;
    default:
        console.log("Número inválido! Digite um número de 1 a 7.");
}

//Atividade B
let cor = prompt("Digite uma cor:").toLowerCase(); // Converte para minúsculas

switch (cor) {
    case "vermelho":
        console.log("O vermelho representa paixão e intensidade!");
        break;
    case "azul":
        console.log("O azul transmite calma e confiança!");
        break;
    case "verde":
        console.log("O verde simboliza a natureza e a esperança!");
        break;
    default:
        console.log("Essa cor não está na lista, mas todas as cores são incríveis!");
}
