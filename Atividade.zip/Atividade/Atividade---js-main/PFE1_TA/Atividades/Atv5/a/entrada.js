let nome = prompt("Digite o seu nome: ")
console.log(`Seja bem-vindo ${nome}`);
