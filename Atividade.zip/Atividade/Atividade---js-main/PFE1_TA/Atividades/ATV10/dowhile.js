//Atividade A
let num;

do{
    num = prompt('Digite um número (se caso deseja sair, digite 0): ');
    if (num !== '0') alert(`O dobro do ${num} é ${num * 2}`);
        
} while (num !== '0');

alert('Saindo...')

//Atividade B
let nome;

do {
    nome = prompt('Digite um nome: ');
} while (nome.toLowerCase() !== 'sair');

alert('Você saiu!');

