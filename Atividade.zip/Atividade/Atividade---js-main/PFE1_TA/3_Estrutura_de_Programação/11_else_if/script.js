let nome = "Juca";
let idade = 17;

if(nome != undefined && nome == "Joaquim"){
    console.log("Nome esta definido");
}else if(nome != undefined && nome.length >= 5 && idade == 50){
    console.log("Meu nome é Juca!");
}else {
    console.log(("Não é Juca"));
}
