console.log(1 > 2);
console.log(5 < 10);
console.log(3 >= 3);
console.log(5 <= 4);
console.log(2 == 2);
console.log(3 === '3');
