console.log(typeof ('123' + 4));
console.log('123' + 4);
console.log(typeof ('30' - 20));
console.log('30' - 20);
console.log('30' + 20);
console.log('30' * 20);
console.log('30' / 20);