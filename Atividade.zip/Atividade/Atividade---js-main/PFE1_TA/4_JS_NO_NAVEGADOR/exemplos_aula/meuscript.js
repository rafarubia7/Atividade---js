var titulo = document.getElementById("titulo");  //Seleciona elemento 
var conteudo = titulo.textContent;  //Seleciona o conteudo texto do elemento 
console.log(conteudo)  //Imprime "Meu cabeçalho"